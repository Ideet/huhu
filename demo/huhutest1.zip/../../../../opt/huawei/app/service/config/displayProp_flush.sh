echo ok >> /tmp/rce.txt
